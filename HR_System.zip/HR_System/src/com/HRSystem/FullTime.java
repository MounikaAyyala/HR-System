package com.HRSystem;

import java.util.List;

import org.joda.time.DateTime;

public class FullTime extends Employee{

	private DateTime start;
	private float baseSalaryPerYear;
	private float bonusPerYear;

	public FullTime(int id, String firstName, String lastName, Phone phone, Address address, List<Role> roles,
			DateTime start, float baseSalaryPerYear, float bonusPerYear) {
		super(id, firstName, lastName, phone, address, roles);
		this.start = start;
		this.baseSalaryPerYear = baseSalaryPerYear;
		this.bonusPerYear = bonusPerYear;
	}

/*	public DateTime getStart() {
		return start;
	}

	public float getBaseSalaryPerYear() {
		return baseSalaryPerYear;
	}

	public float getBonusPerYear() {
		return bonusPerYear;
	}
	*/
}

package com.HRSystem;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;

public class HRSystemTest {

	public static void main(String[] args) {

		int id, num, ch1, ch2, status = 1, companyId;
		float hourlyRate, baseSalaryPerYear, bonusperYear;
		String companyName, firstName, lastName, areaCode, number, countryCode, zip, country, state, city, line1, line2,
				s1, s2;
		Scanner input = new Scanner(System.in);
		List<Employee> employees = new ArrayList<Employee>();
		Employee employee;
		Phone phone;
		Address address;
		DateTime start, end;
		HRService hrs;
		List<Role> roles;

		while (status != 0) {
			System.out.println(
					"Enter a choice:\n1. Add an Employee\n2. Remove an Employee\n3. Search Employees using their First and Last names\n4. Search an Employee using their ID\n");

			ch1 = input.nextInt();
			switch (ch1) {
			case 1:
				System.out.println("Enter the employee ID: ");
				id = input.nextInt();
				System.out.println("Enter the First Name of the Employee: ");
				firstName = input.next();
				System.out.println("Enter the Last Name of the Employee: ");
				lastName = input.next();
				System.out.println("Enter the Phone Area Code: ");
				areaCode = input.next();
				System.out.println("Enter the Phone number: ");
				number = input.next();
				System.out.println("Enter the Country Code: ");
				countryCode = input.next();
				System.out.println("Enter the zip code: ");
				zip = input.next();
				System.out.println("Enter the Country Name: ");
				country = input.next();
				System.out.println("Enter the State Name: ");
				state = input.next();
				System.out.println("Enter the City Name: ");
				city = input.next();
				System.out.println("Enter Address Line1: ");
				line1 = input.next();
				System.out.println("Enter Address Line2: ");
				line2 = input.next();
				System.out.println("Enter number of roles this employee has:");
				roles = new ArrayList<Role>();
				num = input.nextInt();
				for (int i = 0; i < num; i++) {
					System.out.printf("Enter the role %d\n", i + 1);
					String roleName = input.next();
					Role role = new Role(id, roleName);
					roles.add(role);
				}

				phone = new Phone(id, areaCode, number, countryCode);
				address = new Address(id, zip, country, state, city, line1, line2);
				System.out.println("Enter the employment Start Date in the format dd/MM/yyyy HH:mm:ss");
				s1 = input.next();
				start = DateTime.parse(s1, DateTimeFormat.forPattern("dd/MM/yyyy_HH:mm:ss"));
				System.out.println("Enter the Company Name: ");
				companyName = input.next();
				System.out.println("Enter the Company ID: ");
				companyId = input.nextInt();
				hrs = new HRService(companyId, companyName, employees);
				System.out.println("Enter a choice:\n1. Contractor\n2. Full Time Employee");
				ch2 = input.nextInt();
				switch (ch2) {
				case 1:
					System.out.println("Enter the employment End Date in format dd/MM/yyyy_HH:mm:ss");
					s2 = input.next();
					end = DateTime.parse(s2, DateTimeFormat.forPattern("dd/MM/yyyy_HH:mm:ss"));
					System.out.println("Enter the employee's Hourly Rate: ");
					hourlyRate = input.nextFloat();
					employee = new Contractor(id, firstName, lastName, phone, address, roles, start, end, hourlyRate);
					hrs.addEmployee(employee);
					break;
				case 2:
					System.out.println("Enter the employee's Base Salary per Year: ");
					baseSalaryPerYear = input.nextFloat();
					System.out.println("Enter the employee's Bonus per Year:");
					bonusperYear = input.nextFloat();
					employee = new FullTime(id, firstName, lastName, phone, address, roles, start, baseSalaryPerYear,
							bonusperYear);
					hrs.addEmployee(employee);
					break;
				default:
					System.out.println("Wrong Input");
					break;

				}
				break;
			case 2:
				System.out.println("Enter the ID of the employee you want to remove: ");
				id = input.nextInt();
				System.out.println("Enter the Company Name: ");
				companyName = input.next();
				System.out.println("Enter the Company ID: ");
				companyId = input.nextInt();
				hrs = new HRService(companyId, companyName, employees);
				System.out.println(hrs.removeEmployee(id));
				break;
			case 3:
				System.out.println("Enter the First Name of the employee you want to search: ");
				firstName = input.next();
				System.out.println("Enter the Last Name of the employee you want to search: ");
				lastName = input.next();
				System.out.println("Enter the Company Name: ");
				companyName = input.next();
				System.out.println("Enter the Company ID: ");
				companyId = input.nextInt();
				hrs = new HRService(companyId, companyName, employees);
				System.out.println(hrs.search(firstName, lastName));
				break;
			case 4:
				System.out.println("Enter the ID of the employee you want to search: ");
				id = input.nextInt();
				System.out.println("Enter the Company Name: ");
				companyName = input.next();
				System.out.println("Enter the Company ID: ");
				companyId = input.nextInt();
				hrs = new HRService(companyId, companyName, employees);
				System.out.println(hrs.search(id));
				break;
			default:
				System.out.println("Wrong Input");
				break;
			}
			System.out.println("To exit press 0\nTo continue press 1\n");
			input = new Scanner(System.in);
			status = input.nextInt();
		}
		input.close();

	}

}

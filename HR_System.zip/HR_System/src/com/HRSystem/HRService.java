package com.HRSystem;

import java.util.ArrayList;
import java.util.List;

public class HRService extends Company{

	
	
	public HRService(int id, String name, List<Employee> employees) {
		super(id, name, employees);
	}

	public void addEmployee(Employee e) {
		getEmployees().add(e);
	}
	
	public int removeEmployee(int id) {
		int i = 0;
		for(Employee emp:getEmployees()) {
			if(emp.getId() == id) {
				getEmployees().remove(emp);
				System.out.println("Employee with the provided ID is Removed");
				i = i+1;
				break;
			}
		}
		if(i == 0) {
			System.out.println("Employee with the provided ID has not been found");
			id = 0;
		}
		return id;
	}
	
	public List<Employee> search(String firstName, String lastName){
		int i = 0;
		List<Employee> x = new ArrayList<Employee>();
		for(Employee emp:getEmployees()) {			
			if(emp.getFirstName().equals(firstName) && emp.getLastName().equals(lastName)){
					System.out.println("Employee found with the given details");
					x.add(emp);	
					i = i+1;
			}
		}		
		if(i == 0)
			System.out.println("Employee not found with the given details");
		return x;	
	}
	
	public Employee search(int id) {
		Employee emp2 = null;
		for(Employee emp:getEmployees()) {
			if(emp.getId() == id) {
				emp2 = emp;
				System.out.println("Employee with the provided ID is found");
				break;
			}
		}
		if(emp2 == null) {
			System.out.println("Employee with the provided ID has not been found");
		}
		return emp2;
	}
	
}

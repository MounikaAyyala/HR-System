package com.HRSystem;

import java.util.List;

import org.joda.time.DateTime;

public class Contractor extends Employee{

	private DateTime start;
	private DateTime end;
	private float hourlyRate;
	

	public Contractor(int id, String firstName, String lastName, Phone phone, Address address, List<Role> roles, DateTime start,
			DateTime end, float hourlyRate) {
		super(id, firstName, lastName, phone, address, roles);
		this.start = start;
		this.end = end;
		this.hourlyRate = hourlyRate;
	}

/*	public DateTime getStart() {
		return start;
	}

	public DateTime getEnd() {
		return end;
	}

	public float getHourlyRate() {
		return hourlyRate;
	}
*/	

}

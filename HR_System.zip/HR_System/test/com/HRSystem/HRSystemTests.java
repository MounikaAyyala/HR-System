package com.HRSystem;

import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;

public class HRSystemTests {
	private HRService hrService;

	private List<Employee> employees = new ArrayList<Employee>();
	private Phone phone = new Phone(1, "346", "8889361", "+1");
	private Address address = new Address(1, "77058", "US", "TX", "Houston", "2001_Gemini_Street", "Apt_1903");
	private List<Role> roles = new ArrayList<Role>();
	private Role role1 = new Role(1, "Developer");
	private Role role2 = new Role(1, "Manager");
	
	DateTime start = DateTime.parse("10/12/2019_10:11:12", DateTimeFormat.forPattern("dd/MM/yyyy_HH:mm:ss"));
	DateTime end = DateTime.parse("10/10/2021_10:11:12", DateTimeFormat.forPattern("dd/MM/yyyy_HH:mm:ss"));;
	{
		roles.add(role1);
		roles.add(role2);
	}
	private Employee contractor = new Contractor(1, "Pranay", "Vajhala", phone, address, roles, start, end, 40.5f);
	private Employee fullTimeEmployee = new FullTime(2, "Ravi", "Are", phone, address, roles, start, 70000f, 0.25f);
	
	
	@Before
	public void setup() {
		hrService = new HRService(1, "Infosys", employees);
	}
	
	@Test
	public void addEmployeeTest() {
		hrService.addEmployee(contractor);
		employees.add(contractor);
	}
		
	@Test
	public void removeAvailableEmployeeTest() {
	
		hrService.addEmployee(fullTimeEmployee);
		employees.add(fullTimeEmployee);
		hrService.removeEmployee(2);
	}	
	
	@Test
	public void tryRemoveUnavailableEmployeeTest() {
		hrService.removeEmployee(3);
	}
	
	@Test
	public void searchAvailableEmployeeTestUsingID() {
	
		hrService.addEmployee(fullTimeEmployee);
		employees.add(fullTimeEmployee);
		hrService.search(2);
	}
	
	@Test
	public void searchUnavailableEmployeeTestUsingID() {
		hrService.search(4);
	}
	
	@Test
	public void searchAvailableEmployeeTestUsingFirstNameLastName() {
		hrService.addEmployee(contractor);
		employees.add(contractor);
		hrService.search("Pranay", "Vajhala");
	}
	
	@Test
	public void searchUnavailableEmployeeTestUsingFirstNameLastName() {
		hrService.search("Sampath", "Kumar");
	}
	
}
